void foo(int a[], int n)
{
    int i;
    int s = 0;
    for (i = 0; i < n; i++)
    {
        s += a[i];
        if (a[i] == 0)
        {
            a[i] = s;
            s = 0;
        }
    }
}