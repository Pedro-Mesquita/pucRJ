#include <stdio.h>

int fat(int n);

int main(void)
{
    printf("%d\n", fat(3));
    return 0;
}