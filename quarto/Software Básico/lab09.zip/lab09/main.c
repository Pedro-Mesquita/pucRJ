#include <stdio.h>

int addNum(int a, int b, int c);

int main(void)
{
    printf("%d\n", addNum(1, 2, 3));
    return 0;
}