#define KEY "SHOWDEBOLA"
#define TRUE 1
#define FALSE 0
void cypher(char *text, char *key, int pos, int encipher);